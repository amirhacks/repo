Creativity is the process of having original ideas that have value. It is a process; it's not random.
-- Ken Robinson
